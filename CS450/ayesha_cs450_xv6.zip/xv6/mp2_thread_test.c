#include"types.h"
#include"user.h"


int i = 0;
uint* stack;
uint* stack1;






// stackwitching + arg passing testing
void b(void* arg){
  char* c = (char*)arg;
  //annouce that function has benn entered + check argument
  printf(1, "1 start of thread argument passed = %s\n", c);
  printf(1,"\n\n");
  printf(1,"end of thread 1\n");
  exit();
}

void a(void* arg1){
  char* c1 = (char*)arg1;
  //annouce that function has benn entered + check argument
  printf(1, "2 start of thread argument passed = %s\n", c1);
  printf(1,"\n\n");
  printf(1,"end of thread 2\n");
  exit();
}

int main(int argc, char** argv){

  //parent();
  stack = (uint*) malloc(32*sizeof(uint));
stack1 = (uint*) malloc(32*sizeof(uint));


  uint* returnstack = (uint*)0;
  uint* returnstack1 = (uint*)0;
  char arg[8] = "t1";
  char arg1[8] = "t2";

thread_create(a, (void*)stack1, (void*)arg1);
  thread_create(b, (void*)stack, (void*)arg);

  //printf(1,"start of sleep in main . main pid = %d, thread pid = %d\n", getpid(), pid);
  sleep(50);
  thread_join((void**)&returnstack);
  thread_join((void**)&returnstack1);
  printf(1, "returnstack address %d, stack address %d\n",(uint)(returnstack), stack);
  printf(1, "returnstack address %d, stack address %d\n",(uint)(returnstack1), stack1);

  free(stack);
  printf(1,"end of main\n");
  exit();
  return 0;
}
