PHONE    
----------
3125559403


F_NAME               L_NAME             
-------------------- --------------------
Leslie               Blackburn           


F_NAME               L_NAME             
-------------------- --------------------
Annie                Heard               
James                Robertson           

F_NAME               L_NAME             
-------------------- --------------------
Abby                 Smith               
Harry                Tang                


F_NAME               L_NAME             
-------------------- --------------------
Abby                 Smith               
Mike                 OShea               
Harry                Tang                
Laura                Dickinson           
Emily                Citrin              
April                OShea               
Dongmei              Tang                
Maria                Garcia              

 8 rows selected 

F_NAME               L_NAME             
-------------------- --------------------
Mike                 OShea               
April                OShea               
Harry                Smith               
Justin               Smith               
Lisa                 Brown               


TYPE
--------------------
DESCRIPTION
--------------------------------------------------------------------------------
Art                  
Painting, sculpting, etc                                                        

Kids                 
Courses geared towards children 13 and younger                                  

Craft                
Knitting, sewing, etc                                                           


TYPE
--------------------
DESCRIPTION
--------------------------------------------------------------------------------
Languages            
Anything to do with writing, literature, or communication                       

Exercise             
Any courses having to do with physical activity                                 


