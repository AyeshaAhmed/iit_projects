/* 
 * Andrew Caron, Emily Warman, Ayesha Ahmed
 * CS 425
 * HW 2
*/
BEGIN
  
-- Query 1  
  Question1('Jurassic Park'); 

-- Query 2
  DBMS_OUTPUT.PUT_LINE('');
  Question2('4444 Devon Ave');

-- Query 3
  DBMS_OUTPUT.PUT_LINE('');
  Question3('Dob Bole');

END;