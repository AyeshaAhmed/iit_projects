begin
query1('Jurassic Park');
DBMS_OUTPUT.put_line('');
query2;
DBMS_OUTPUT.put_line('');
query3;
DBMS_OUTPUT.put_line('');
query5;
DBMS_OUTPUT.put_line('');
query6;
DBMS_OUTPUT.put_line('');
query7;
DBMS_OUTPUT.put_line('');
query8;
DBMS_OUTPUT.put_line('');
query9;
end;