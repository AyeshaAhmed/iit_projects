public class EmployeeTrain
{
	int id;
	boolean janitor;
	boolean salesrep;
	boolean ticketmaster;
	
	public EmployeeTrain(int i, boolean j, boolean s, boolean t)
	{
		id = i;
		janitor = j;
		salesrep = s;
		ticketmaster = t;
	}
}
